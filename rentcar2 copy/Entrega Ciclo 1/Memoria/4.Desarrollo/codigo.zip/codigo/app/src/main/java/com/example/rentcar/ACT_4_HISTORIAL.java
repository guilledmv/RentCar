package com.example.rentcar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ACT_4_HISTORIAL extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_4_historial);
    }
}